#!/usr/bin/env bash
set -euo pipefail

# ──────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────
APP_NAME="BIDSManager"
INSTALL_DIR="$HOME/BIDS_MANAGER"
PORTABLE_PYTHON_URL="https://raw.githubusercontent.com/ANCPLabOldenburg/BIDS-Manager/main/external/python-embed/python-3.10.13%2B20240107-x86_64-unknown-linux-gnu-install_only.zip"
ENV_DIR="$INSTALL_DIR/env"
PYTHON_BIN="$INSTALL_DIR/bin/python3.10"
DESKTOP_DIR="$HOME/Desktop"
APPDIR="$HOME/.local/share/applications"

mkdir -p "$INSTALL_DIR" "$APPDIR"

# ──────────────────────────────────────────────────────────────
# Step 1: Detect usable Python 3.10 or download portable version
# ──────────────────────────────────────────────────────────────
USE_PORTABLE=true

if $USE_PORTABLE; then
    echo "[*] Downloading portable Python 3.10..."
    cd "$INSTALL_DIR"
    ZIP_NAME="$(basename "$PORTABLE_PYTHON_URL" | sed 's/%2B/+/g')"  # decode URL-encoded '+'
    wget -q --show-progress -O "$ZIP_NAME" "$PORTABLE_PYTHON_URL"
    echo "[*] Unzipping..."
    unzip -q "$ZIP_NAME"
    rm "$ZIP_NAME"
    # optional: if decompress in a subdirectory, move it
    if [ -d "python" ]; then
        mv python/* .
        rmdir python
    fi
    PYTHON="$PYTHON_BIN"
fi

# ──────────────────────────────────────────────────────────────
# Step 2: Create virtual environment and install BIDS Manager
# ──────────────────────────────────────────────────────────────
echo "[*] Creating virtual environment..."
"$PYTHON" -m venv "$ENV_DIR"
source "$ENV_DIR/bin/activate"
pip install --upgrade pip
pip install bids-manager
deactivate

# ──────────────────────────────────────────────────────────────
# Step 3: Create launcher script
# ──────────────────────────────────────────────────────────────
RUN_SCRIPT="$INSTALL_DIR/run_bidsmanager.sh"
cat > "$RUN_SCRIPT" <<EOF
#!/usr/bin/env bash
source "$ENV_DIR/bin/activate"
bids-manager
EOF
chmod +x "$RUN_SCRIPT"

# ──────────────────────────────────────────────────────────────
# Step 4: Create uninstaller script
# ──────────────────────────────────────────────────────────────
UNINSTALL_SCRIPT="$INSTALL_DIR/uninstall_bidsmanager.sh"
cat > "$UNINSTALL_SCRIPT" <<EOF
#!/usr/bin/env bash
echo "[*] Removing $INSTALL_DIR..."
rm -rf "$INSTALL_DIR"

echo "[*] Removing launchers..."
rm -f "$DESKTOP_DIR/BIDSManager.desktop"
rm -f "$DESKTOP_DIR/Uninstall_BIDSManager.desktop"
rm -f "$APPDIR/BIDSManager.desktop"
rm -f "$APPDIR/Uninstall_BIDSManager.desktop"

echo "[*] Removing PATH override from ~/.bashrc..."
sed -i '/# >>> BIDSManager Python/,/# <<< BIDSManager Python/d' "$HOME/.bashrc"

echo "[*] Uninstallation complete."
EOF
chmod +x "$UNINSTALL_SCRIPT"

# ──────────────────────────────────────────────────────────────
# Step 5: Create desktop launchers
# ──────────────────────────────────────────────────────────────
if [[ -d "$DESKTOP_DIR" ]]; then
    echo "[*] Creating desktop shortcuts..."

    # Run launcher
    cat > "$APPDIR/BIDSManager.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=BIDS Manager
Comment=Launch BIDS Manager
Exec=$RUN_SCRIPT
Terminal=true
Icon=utilities-terminal
EOF
    cp "$APPDIR/BIDSManager.desktop" "$DESKTOP_DIR/"
    chmod +x "$DESKTOP_DIR/BIDSManager.desktop"

    # Uninstall launcher
    cat > "$APPDIR/Uninstall_BIDSManager.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Uninstall BIDS Manager
Comment=Completely remove BIDS Manager
Exec=$UNINSTALL_SCRIPT
Terminal=true
Icon=utilities-terminal
EOF
    cp "$APPDIR/Uninstall_BIDSManager.desktop" "$DESKTOP_DIR/"
    chmod +x "$DESKTOP_DIR/Uninstall_BIDSManager.desktop"
else
    echo "[!] Desktop directory not found. Skipping desktop icon creation."
fi

# ──────────────────────────────────────────────────────────────
# Step 6: Set portable Python as default (user-only)
# ──────────────────────────────────────────────────────────────
if ! grep -q '# >>> BIDSManager Python' "$HOME/.bashrc"; then
    echo "[*] Setting portable Python as the default Python in ~/.bashrc..."
    cat >> "$HOME/.bashrc" <<EOF

# >>> BIDSManager Python
export PATH="$INSTALL_DIR/bin:\$PATH"
# <<< BIDSManager Python
EOF
fi

# ──────────────────────────────────────────────────────────────
# Done!
# ──────────────────────────────────────────────────────────────
echo ""
echo "✅ BIDS Manager was successfully installed!"
echo "→ Run it via the desktop icon or with:  bash $RUN_SCRIPT"
echo "→ Uninstall it with:                   bash $UNINSTALL_SCRIPT"
echo "→ Restart your terminal to use Python 3.10 by default."

